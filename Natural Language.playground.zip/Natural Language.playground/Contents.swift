import Foundation
import NaturalLanguage

let text = "Whenever Tim Cook leaves Apple Inc., he makes sure to pack his iPad and his iPhone. Craig Federighi, on the other hand, thinks it's a priority to travel with a MacBook."
let options: NLTagger.Options = [.omitPunctuation, .omitWhitespace, .joinNames]
let tags: [NLTag] = [.personalName, .organizationName, .placeName]

// 1
var productTagScheme = NLTagScheme("Product")
var productTag = NLTag("PROD")

// 2
let modelURL = Bundle.main.url(forResource: "ProductTagger", withExtension: "mlmodelc")!
let productTaggerModel = try! NLModel(contentsOf: modelURL)

// 3
let productTagger = NLTagger(tagSchemes: [.nameType, productTagScheme])
productTagger.setModels([productTaggerModel], forTagScheme: productTagScheme)

// 4
productTagger.string = text
productTagger.enumerateTags(in: text.startIndex..<text.endIndex, unit: .word, scheme: .nameType, options: options) { (tag, tokenRange) -> Bool in
    if let tag = tag, tags.contains(tag) {
        print("\(text[tokenRange]): \(tag.rawValue)")
    }
    return true
}

productTagger.enumerateTags(in: text.startIndex..<text.endIndex, unit: .word, scheme: productTagScheme, options: options) { (tag, tokenRange) -> Bool in
    if tag == productTag {
        print("\(text[tokenRange]): PROD")
    }
    return true
}


